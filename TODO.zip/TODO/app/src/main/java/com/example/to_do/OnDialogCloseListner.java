package com.example.to_do;

import android.content.DialogInterface;

public interface OnDialogCloseListner {

    void onDialogClose(DialogInterface dialogInterface);
}